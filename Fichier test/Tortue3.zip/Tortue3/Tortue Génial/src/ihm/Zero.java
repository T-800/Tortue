package ihm;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import objetQuiDessine.CurseurQuiDessine;

public class Zero extends JPanel{
	
	
	
	static Dimension tailleEcran = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
	int hauteur;
	int largeur;
	
	Terminal terminal;
	Dessin dessin;
	PanelHistory history;
	Info info;
	
	public Zero() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		Rectangle bounds = ge.getMaximumWindowBounds();
		largeur = bounds.width;
		hauteur = bounds.height;
		
		this.info = new Info();
		this.dessin = new Dessin(info);
		this.history = new PanelHistory();
		
		
		this.terminal = new Terminal(history,dessin);
		
		final JScrollPane historyScroller = new JScrollPane( history,
	            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
	            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER );
		
		
		terminal.setPreferredSize(new Dimension(largeur/100*100,hauteur/100*5));
		historyScroller.setPreferredSize(new Dimension(largeur/100*20,hauteur/100*90));
		dessin.setPreferredSize(new Dimension(largeur/100*80,hauteur/100*90));
		info.setPreferredSize(new Dimension(largeur/100*100,hauteur/100*3));
		
	    this.setPreferredSize(new Dimension(largeur, hauteur));
	    this.setBackground(Color.lightGray);
	    //On d�finit le layout manager
	    this.setLayout(new GridBagLayout());
			
	    //L'objet servant � positionner les composants
	    GridBagConstraints gbc = new GridBagConstraints();
		
	    //On positionne la case de d�part du composant
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    //La taille en hauteur et en largeur
	    gbc.gridheight = 1;
	    gbc.gridwidth = 1;
	    this.add(dessin, gbc);
	    //---------------------------------------------
	    gbc.gridwidth = GridBagConstraints.REMAINDER;
	    gbc.gridx = 1;
	    this.add(historyScroller, gbc);
	    gbc.gridx = 0;
	    gbc.gridy = 1;
	    //gbc.fill = GridBagConstraints.HORIZONTAL;
	    gbc.gridwidth = GridBagConstraints.REMAINDER;
	    this.add(info, gbc);
	    gbc.gridx = 0;
	    gbc.gridy = 2;
	    this.add(terminal,gbc);
	  
	   
	}

}
