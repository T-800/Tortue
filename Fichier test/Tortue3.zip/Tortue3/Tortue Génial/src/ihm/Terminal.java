package ihm;

import history.historyTerminal;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JTextField;
import commande.Autocompletion;
import commande.HashTable;

public class Terminal extends JTextField{
	
	public historyTerminal historyterminal;
	public PanelHistory panelHistory;
	public Dessin dessin;
	Info info;
	
	
	public Terminal(PanelHistory panelhistory,Dessin dessin) {
		this.panelHistory = panelhistory;
		this.dessin=dessin;
		
		this.setBackground(Color.black);
		 historyterminal = new historyTerminal();
		addKeyListener(new KeyListenTerminal(this));
		 
		 this.setForeground(Color.white);
		 this.setFocusTraversalKeysEnabled(false);
	}
	
	
	
	
	
	
	public class KeyListenTerminal implements KeyListener {
		public Terminal terminal;
		public HashTable table;
		
		
		public KeyListenTerminal(Terminal terminal) {
			this.terminal= terminal;
			this.table = new HashTable(panelHistory);
		}

		@Override
		public void keyPressed(KeyEvent e) {

			String s;
			if(e.getKeyCode() == KeyEvent.VK_ENTER) {
				terminal.historyterminal.reset();
				
				 s=terminal.getText();
				 s=s.trim();
				 if(s.equals("")){
					 
					 return;
				}
				 terminal.setText("");
				 historyTerminal.addToHistory(s);
				 try {
					 HashTable.hgj(s, terminal.dessin.curseur, terminal.dessin,true);
					
				 } catch (NullPointerException e1) {
					 e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
			else if(e.getKeyCode() == KeyEvent.VK_UP) {
				terminal.setText(historyterminal.showUp());
			}
			else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				terminal.setText(historyterminal.showDown());
			}
			else if((e.getKeyCode() == KeyEvent.VK_TAB)) {
				historyterminal.reset();
				 s=terminal.getText();
				 s=s.trim();
				Autocompletion a = new Autocompletion();
				ArrayList<String>tab = Autocompletion.complete(s);
				//System.out.println(tab.size());
				if (tab.size()>1){
					for(int i=0;i<tab.size()-1;i++){
						System.out.println(tab.get(i));
						panelHistory.addTexteIndent("- "+tab.get(i)+"\n");	
					}
				}else if(tab.size()==1){
					terminal.setText(tab.get(tab.size()-1));
				}
				
			}else if ((e.getKeyCode() == KeyEvent.VK_L) && ((e.getModifiers() & KeyEvent.CTRL_MASK) != 0)) {
				panelHistory.clear();
				
			}
			
		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		

	}
	

}
