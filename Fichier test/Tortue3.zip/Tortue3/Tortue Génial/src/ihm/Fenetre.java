package ihm;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.ImageObserver;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import objetQuiDessine.CurseurQuiDessine;

public class Fenetre extends JFrame{

	public Fenetre() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		Rectangle bounds = ge.getMaximumWindowBounds();
		
		              
	    this.setTitle("TortueGenial");
	    ImageIcon img = new ImageIcon("../Image/logo.gif");
	    this.setIconImage(img.getImage());
	    this.setSize(bounds.width, bounds.height);
	    Zero zero = new Zero();

		this.setResizable(false);
		
		 //On ajoute le conteneur
	    this.setContentPane(zero);
	    //zero.repaint();
	    this.setVisible(true);
	    this.pack();

	   
	  }

}
