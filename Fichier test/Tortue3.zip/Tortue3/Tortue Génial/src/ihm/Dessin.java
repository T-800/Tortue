package ihm;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import commande.Circle.Cercle;
import commande.Move.Ligne;
import java.awt.BasicStroke;
import commande.Pensize.Size;

import javax.swing.JPanel;

import objetQuiDessine.CurseurQuiDessine;

@SuppressWarnings("serial")
public class Dessin extends JPanel implements MouseMotionListener{

	public ArrayList<Object> cmd = new ArrayList<Object>();
	public CurseurQuiDessine curseur;
	public Info info;
	public Color getBackground() {
		return background;
	}


	public void setBackground(Color background) {
		this.background = background;
	}


	private Color background;
	int i =0;
	
	
	public Dessin(Info info){
		this.info = info;
		this.curseur= new CurseurQuiDessine(info,this.getWidth()/2,this.getHeight()/2);
		info.curs = curseur;
		
		
		addMouseMotionListener(this);
		setOpaque(true);
		background = Color.white;
	}
	

	public void paintComponent(Graphics g){
		
		super.paintComponent(g);
		//curseur.setCurseurImg(replaceImage(curseur.getCurseurImg(),90.0));
		
		Graphics2D g2 = (Graphics2D)g;
		g2.drawImage(curseur.getCurseurImg(), curseur.getAbscisse(), curseur.getOrdonnee(), this);    
		
		
		/*System.out.println("i = "+i);
		i++;
		System.out.println(cmd.size());*/
		//Stroke s = g2.getStroke();
		g2.setStroke(new BasicStroke(1));
		for(Object p : this.cmd){
			if(p.getClass().equals(Ligne.class)){
				Ligne l = (Ligne)p;
                g2.setColor(l.getColor());
                g2.drawLine(l.getxDepart(), l.getyDepart(), l.getxArrivee(), l.getyArrivee());
                
            }
			else if(p.getClass().equals(Cercle.class)){
				Cercle c = (Cercle)p;
				g2.setColor(c.getColor());
				g2.drawArc(c.getxDepart(), c.getyDepart(), c.getRayon(), c.getRayon(),90, c.getDegree());
				
			}
			else if(p.getClass().equals(Size.class)){
				Size s = (Size)p;
				g2.setStroke(new BasicStroke(s.getStrockeSize(),BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER));
				
			}
       }
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		int x=e.getX(),y=e.getY();
		if (x > this.getWidth() / 2) {
			x -= this.getWidth() / 2 ;
		} else {
			x = -this.getWidth() / 2 + x;
		}
		if (y<this.getHeight() / 2) {
			y = this.getHeight() / 2 - y;
		} else {
			y = -(y-this.getHeight() / 2);
		}
		info.setSouris(x,y);
		info.setCurseur(curseur.getAbscisse(), curseur.getOrdonnee(), curseur.getDirection());
		info.setDessine(curseur.getPendown());
		info.setRemember(curseur.getRememberAbscisse(), curseur.getRememberOrdonnee(), curseur.getRememberDirection());
	}
	
	
	public boolean egaux(Ligne l1,Ligne l2){
		if(l1.getxArrivee()!=l2.getxArrivee())return false;
		if(l1.getxDepart()!=l2.getxDepart())return false;
		if(l1.getyArrivee()!=l2.getyArrivee())return false;
		if(l1.getyDepart()!=l2.getyDepart())return false;
		//if(!(l1.getStrok()==l2.getStrok()))return false;
		if(!(l1.getColor().getRGB()==l2.getColor().getRGB()))return false;
		return true;
	}
	
	
	public Image replaceImage (Image img, double angleRotation) {
		double absA = Math.abs(angleRotation);
		int w = img.getWidth(this);
		int h = img.getHeight(this);
		int dy = (int) (w * Math.sin(absA));
		int dx = (int) (w - w * Math.cos(absA));
			
		int hauteur = h + dy;
		int largeur = w - dx;
		int delta = (int) (h * Math.sin(absA)); 
			
		BufferedImage imageRotate = new BufferedImage (largeur, hauteur,          BufferedImage.TYPE_4BYTE_ABGR);
		Graphics2D g2d = (Graphics2D) imageRotate.getGraphics();
			
		AffineTransform translation = new AffineTransform ();
		if (angleRotation > 0) {
			translation.translate(0, hauteur - h);
			g2d.transform (translation); 
			translation.setToIdentity();
			translation.translate(-delta, 0);
			g2d.transform (translation); 
		} else {
			translation.translate(delta, 0);
			g2d.transform (translation);
		}
					
			
		AffineTransform rotation = new AffineTransform ();
		rotation.rotate(-angleRotation);
		
		
		g2d.transform(rotation);		
		g2d.drawImage(img, 0, 0, this);
		return imageRotate;
	}
	
	
	    
}
