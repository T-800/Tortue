package commande;

import ihm.Dessin;

import java.io.IOException;

import objetQuiDessine.CurseurQuiDessine;

public class Center implements Commande {

	// Place le curseur au centre de l'image
	/*
	 * Trouver un moyen pour qu'on recupere la taille du panel dessin du dessin
	 */

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) throws IOException {
		// TODO Auto-generated method stub
		curseur.setAbscisse(dessin.getWidth() / 2);
		curseur.setOrdonnee(dessin.getHeight() / 2);
		if (addToHistory)
			history.addToHistory(ToString(parametres));
		dessin.repaint();
	}

	
	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}
