package commande;

import ihm.Dessin;
import objetQuiDessine.CurseurQuiDessine;

public class Redo implements Commande {

	// refait la commande qui a �t� annul�e

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		// TODO Auto-generated method stub
		history.redo();
	}

	

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}



	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}
