package commande;

import java.io.IOException;

import ihm.Dessin;
import objetQuiDessine.CurseurQuiDessine;

public class Down implements Commande {

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) throws IOException {
		curseur.setDirection(270);
		if (addToHistory)
			history.addToHistory(ToString(parametres));

	}

	

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}



	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}
