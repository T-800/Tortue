package commande;

import ihm.*;
import java.awt.Color;
import objetQuiDessine.CurseurQuiDessine;

public class BackgroundColor implements Commande {

	HashTable table;

	public Color convertiCouleur(String s) {
		s.toLowerCase();
		if (s.equals("black") || s.equals("noir") || s.equals("#000000")) {
			return Color.black;
		}
		if (s.equals("blanc") || s.equals("white") || s.equals("#ffffff")) {
			return Color.white;
		}
		if (s.equals("blue") || s.equals("bleu") || s.equals("#0000ff")) {
			return Color.blue;
		}
		if (s.equals("cyan") || s.equals("#00ffff")) {
			return Color.cyan;
		}
		if (s.equals("jaune") || s.equals("yellow") || s.equals("#ffff00")) {
			return Color.yellow;
		}
		if (s.equals("red") || s.equals("rouge") || s.equals("#ff0000")) {
			return Color.red;
		}
		if (s.equals("rose") || s.equals("pink") || s.equals("#fd6c9e")) {
			return Color.pink;
		}
		if (s.equals("orange") || s.equals("#ed7f10")) {
			return Color.orange;
		}
		if (s.equals("magenta") || s.equals("#ff00ff")) {
			return Color.magenta;
		}
		if (s.equals("lightgray") || s.equals("gris clair")
				|| s.equals("#afafaf")) {
			return Color.lightGray;
		}
		if (s.equals("green") || s.equals("vert") || s.equals("#00ff00")) {
			return Color.green;
		}
		if (s.equals("gray") || s.equals("gris") || s.equals("#606060")) {
			return Color.gray;
		}
		if (s.equals("darkgray") || s.equals("gris fonce")
				|| s.equals("#463F32")) {
			return Color.darkGray;
		} else {
			try {
				return Color.decode(s);
			} catch (NumberFormatException e1) {
				return Color.white;
			}

		}
	}

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		// TODO Auto-generated method stub
		if (addToHistory)
			history.addToHistory(ToString(parametres));
		curseur.setBackground(convertiCouleur(parametres[1]));
		dessin.setBackground(convertiCouleur(parametres[1]));
		dessin.repaint();

	}


	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}
}
