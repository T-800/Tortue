package commande;

import java.io.IOException;
import java.util.ArrayList;

import ihm.Dessin;

import objetQuiDessine.CurseurQuiDessine;

public class Undo implements Commande {

	// Commande UNDO : annule la denriere commande executer
	// Ajouter le cas ou on veux annuler la lecture d'un fichier ou d'un repeat

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) throws IOException {

		
		history.removeToHistory();
		
		dessin.cmd = new ArrayList<Object>();
		curseur.setAbscisse(0);
		curseur.setOrdonnee(0);
		curseur.setDirection(0);
		//history.setHistory(new ArrayList<String>());
		for(String s : history.getHistory()){
			HashTable.hgj(s, curseur, dessin, false);
		}
		
		dessin.repaint();
		//new_cmd = new ArrayList<String>();

	}

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}
