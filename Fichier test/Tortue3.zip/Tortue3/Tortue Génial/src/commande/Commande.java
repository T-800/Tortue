package commande;

import history.HistoryTortue;
import ihm.Dessin;
import java.io.IOException;

import objetQuiDessine.CurseurQuiDessine;

public interface Commande {
	
	HistoryTortue history = new HistoryTortue();

	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) throws IOException;

	public String ToString(String[] tab);
	
	public int canDoIt(String[] parametres, Dessin dessin,CurseurQuiDessine curseur);

}
