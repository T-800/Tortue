package commande;

import ihm.Dessin;
import objetQuiDessine.CurseurQuiDessine;

public class Pensize implements Commande {

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		// TODO Auto-generated method stub
		
		Integer x = Integer.parseInt(parametres[1]);

		curseur.setPensize(x.intValue());
		Size s = new Size(x.intValue());
		dessin.cmd.add(s);
		if (addToHistory)
			history.addToHistory(ToString(parametres));
	}

	

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}



	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}



	public class Size {
		private int strokeSize;
		

		public Size(int strokeSize) {
			this.strokeSize = strokeSize;
		}

		

		public int getStrockeSize() {
			return strokeSize;
		}

		public void setyArrivee(int strokeSize) {
			this.strokeSize = strokeSize;
		}

	}

}
