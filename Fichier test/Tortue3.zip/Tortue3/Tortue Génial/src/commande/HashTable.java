package commande;
import ihm.PanelHistory;
import ihm.Dessin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;


import objetQuiDessine.CurseurQuiDessine;

/**
 * Cette classe fait le lien entre l'interpreteur de commande et les differentes
 * fonctions possible
 * 
 * @author Renaud
 * 
 */
public class HashTable {

	static Hashtable<String, Commande> hashCommande = new Hashtable<String, Commande>();
	static PanelHistory panelHistory;

	/**
	 * déclaration de la table de hashage
	 */
	public HashTable(PanelHistory panel) {
		panelHistory = panel;
		
		hashCommande.put("BACK", new Back());
		hashCommande.put("BACKGROUNDCOLOR", new BackgroundColor());
		hashCommande.put("CENTER", new Center());
		hashCommande.put("CIRCLE", new Circle());
		hashCommande.put("CLEAR", new Clear());
		hashCommande.put("DOWN", new Down());
		hashCommande.put("GO", new Go());
		hashCommande.put("ERASE", new Erase());
		hashCommande.put("HELP", new Help());
		hashCommande.put("LEFT", new Left());
		hashCommande.put("MOVE", new Move());
		hashCommande.put("NEW", new New());
		hashCommande.put("OPEN", new Open());
		hashCommande.put("PENCOLOR", new PenColor());
		hashCommande.put("PENDOWN", new PenDown());
		hashCommande.put("PENSIZE", new Pensize());
		hashCommande.put("PENUP", new PenUp());
		hashCommande.put("REDO", new Redo());
		hashCommande.put("REMEMBER", new Remember());
		hashCommande.put("REPEAT", new Repeat());
		hashCommande.put("RIGHT", new Right());
		hashCommande.put("SAVE", new Save());
		hashCommande.put("TURN", new Turn());
		hashCommande.put("UNDO", new Undo());
		hashCommande.put("UP", new Up());
		hashCommande.put("/*", new Commentaire());

	}

	private static boolean isRepeat(String s){
		String d = s.substring(0,6);
		d=d.toUpperCase();
		return d.equals("REPEAT");
	}
	

	private static String[] decoupageNormal(String commande){
		return commande.split(" ");
	}
	
	

	public static void hgj(String commande, CurseurQuiDessine curseur, Dessin dessin,
			boolean add) throws IOException {
		
		/**
		*Supprime tout les espace en trop
		*/
		commande =commande.replaceAll("\\s+", " ");

		/****/

		commande = syntaxe(commande);
		String[] nomCmd = splitSpace(commande);
		nomCmd[0] = nomCmd[0].toUpperCase();
		sendToPanel(nomCmd, commande, add);

		if(hashCommande.containsKey(nomCmd[0])){
			codeErreur(hashCommande.get(nomCmd[0]).canDoIt(nomCmd, dessin, curseur));
			
			if(hashCommande.get(nomCmd[0]).canDoIt(nomCmd, dessin, curseur)==0){
				hashCommande.get(nomCmd[0]).execute(nomCmd, dessin, curseur,add);
			}
		}
		else {
			panelHistory.addError("La commande "+ nomCmd[0].replace("\n", "<br>") + " n'existe pas");
		}

	}
	
	public static boolean itsOK(String[] parametre,boolean repeat,Dessin dessin,CurseurQuiDessine curseur){
		
		return hashCommande.get(parametre[0]).canDoIt(parametre, dessin, curseur)==0;
	
	}
	
	private static void codeErreur(int code){
		switch (code) {
			case 1://arguments pas bon
				panelHistory.addError("Cette fonction ne fonctionne pas avec ces arguments");
				break;

			case 2:// x,y pas dans le dessin
				panelHistory.addError("Les coordonnees x,y se sont pas dans le dessin");
				break;
			case 3://nombre d'aguments
				panelHistory.addError("Le nombre d'agument n'est pas bon");
				break;
			case 4:
				panelHistory.addError("Votre curseur n'est pas pose (Vous ne dessinez pas)");
				break;
			case 5:
				panelHistory.addError("Une commande de votre repeat n'existe pas");
				break;
			case 6:
				panelHistory.addError("Votre boucle ne pourra pas etre execute jusqu'a la fin");
				break;
			case 7:
				panelHistory.addError("Cette fonction n'existe pas");
				break;
			case 8:
	
				break;
			case 9:
				
				break;
				
		}
	}

	// TODO : Ajouter une fonction qui verifie la syntaxe
	/*
	 * Les syntaxes possibles sont : 
	 * -CMD -CMD arg1 arg2 -REPEAT nbFois [CMD arg1 arg2;CMD] 
	 * -REPEAT nbFois [ CMD arg1 arg2 ; CMD ]
	 * 
	 * 
	 * 
	 * Le pire cas de commande a corriger est :
	 * "REPEAT         nbFois        [    CMD   arg1    arg2   ;   CMD   ]"
	 */

	public static String syntaxe(String commande) {
		String[] cmd = commande.split("\\[");
		String s = "";
		String[] cmd2;
		if (cmd.length == 1) {
			cmd2 = splitSpace(cmd[0]);
			s = concat(cmd2);
		} else if (cmd.length == 2) {
			cmd2 = splitSpace(cmd[0]);
			String[] fina = new String[3];
			fina[0] = cmd2[0];
			fina[1] = cmd2[1];
			fina[2] = "[" + cmd[1];
			s = concat(fina);

		} else {
			cmd2 = splitSpace(cmd[0]);
			String[] fina = new String[2+cmd.length-1];
			fina[0] = cmd2[0];
			fina[1] = cmd2[1];
			for(int i =2;i<fina.length;i++){
				fina[i] = "[" + cmd[i-1];
			}
			s = concat(fina);
		}
		return s;

	}

	private static String concat(String[] commande) {
		String s = "";
		for (int i = 0; i < commande.length; i++) {
			s += " " + commande[i];

		}
		s = s.trim();
		return s;
	}

	public static String[] splitSpace(String commande) {
		boolean repeat = false;
		for (int i = 0; i < commande.length(); i++) {
			if (commande.charAt(i) == '[')
				repeat = true;
		}
		String[] cmd2;
		if (repeat) {
			String[] c = commande.split("\\[");
			String[] cmd = c[0].split(" ");
			ArrayList<String> tmp = new ArrayList<String>();
			for (int i = 0; i < cmd.length; i++) {
				cmd[i] = cmd[i].trim();
				if (!cmd[i].equals(""))
					tmp.add(cmd[i]);

			}
			cmd2 = new String[tmp.size() + 1];
			for (int i = 0; i < cmd2.length - 1; i++) {
				cmd2[i] = tmp.get(i);
			}
			cmd2[cmd2.length - 1] = "[" + c[1];
		} else {
			String[] cmd = commande.split(" ");
			ArrayList<String> tmp = new ArrayList<String>();
			for (int i = 0; i < cmd.length; i++) {
				cmd[i] = cmd[i].trim();
				if (!cmd[i].equals(""))
					tmp.add(cmd[i]);

			}
			cmd2 = new String[tmp.size()];
			for (int i = 0; i < cmd2.length; i++) {
				cmd2[i] = tmp.get(i);

			}
		}

		return cmd2;
	}

	public static void sendToPanel(String[] c, String commande, boolean add) {
		if (c[0].equals("REPEAT")) {
			panelHistory.addTexte(commande);
			panelHistory.addTexte("[");
			c[2] = c[2].replaceAll("\\[", "");
			c[2] = c[2].replaceAll("\\]", "");
			String[] cmd = c[2].split(";");
			for (int i = 0; i < cmd.length; i++) {
				cmd[i] = syntaxe(cmd[i]);
			}

			for (int i = 0; i < cmd.length; i++) {

				panelHistory.addTexteIndent(cmd[i]);
				panelHistory.addTexteIndent("\n");

			}
			panelHistory.addTexte("]");

		}else if(c[0].equals("/*")&&add){
			
			panelHistory.addCom(commande);
		}else if (add) {
			
			panelHistory.addTexte(commande);

		}
	}

	

}
