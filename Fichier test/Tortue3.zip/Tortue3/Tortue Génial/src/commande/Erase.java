package commande;

import ihm.Dessin;
import objetQuiDessine.CurseurQuiDessine;
import objetQuiDessine.SymboleQuiDessine;

public class Erase implements Commande {

	// Elle efface d'un nombre de pixel donn�es l trait qu'on a fait
	public static void execute(SymboleQuiDessine s, int n) {
		for (int i = n; i > 0; i--) {

		}
	}

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		// TODO Auto-generated method stub

	}

	
	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}
