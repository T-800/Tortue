package commande;

import ihm.Dessin;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import history.historyTerminal;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

import objetQuiDessine.CurseurQuiDessine;

public class Open implements Commande {

	JFileChooser open = new JFileChooser();
	BufferedReader reader;
	ArrayList<String> list = new ArrayList<String>();
	public Open() {
		FileFilter filter1 = new ExtensionFileFilter("Fichier texte",
				new String[] { "txt" });
		open.setFileFilter(filter1);
		open.setApproveButtonText("Choix du fichier"); // intitulé du bouton
	}

	/*
	 * Syntaxe possible : - open (ouvre un fichier avec une boite de dialogue a
	 * la suite du fichier courant) ==> OK - open path (ouvre le fichier passé
	 * en parametre a la suite du fichier courant) ==> ok - open new (appel a
	 * save) ==> ok - open new path ==> ok
	 */

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) throws IOException {
		if (parametres.length == 1) {
			int ret = open.showDialog(null, "Choix du fichier");

			if (ret == JFileChooser.APPROVE_OPTION) {
				File fileTxt = open.getSelectedFile();
				System.out.println(fileTxt);
				if (rightExtention(fileTxt.getPath()) && fileTxt.exists()) {
					try {
						reader = new BufferedReader(new FileReader(fileTxt));
					} catch (FileNotFoundException e) {

					}

					String ligne = reader.readLine();
					
					while (ligne != null) {
						list.add(ligne);
						ligne = reader.readLine();
					}
					for(String l : this.list){
						String[] cmd = HashTable.splitSpace(l);
						try{
							System.out.println("ff");
							if(!HashTable.itsOK(cmd, false, dessin, curseur)){
								System.out.println("erreur dans le fichier");
								list = new ArrayList<String>();
								return;
							}
						}catch(ArrayIndexOutOfBoundsException e){
							System.out.println("pas de saut de ligne imb�cile");
							list = new ArrayList<String>();
							return;
							
						}
							
					}
					for(String l : this.list){
						HashTable.hgj(l, curseur, dessin, true);
						historyTerminal.addToHistory(l);
						
					}
					list = new ArrayList<String>();

				} else
					System.out.println("Ce n'est pas un fichier txt");

				/*
				 * lecture du fichier
				 */

			}

		} else if (parametres[1].equals("NEW")) {
			// nouveau dessin appel a new
			HashTable.hgj("NEW", curseur, dessin, false);

			if (parametres.length == 2) {
				HashTable.hgj("OPEN", curseur, dessin, false);
			} else
				HashTable.hgj("OPEN" + parametres[2], curseur, dessin, false);

		} else {
			File fileTxt = new File(parametres[1]);
			String s = fileTxt.getPath();
			if (rightExtention(s) && fileTxt.exists()) {
				try {
					reader = new BufferedReader(new FileReader(fileTxt));
				} catch (FileNotFoundException e) {

				}

				String ligne = reader.readLine();
				System.out.println("Ligne n° " + 1 + " :" + ligne);
				int i = 2;
				while (ligne != null) {
					// TODO : SI LA PREMIERE LIGNE N'EST PAS BONNE LE FICHIER
					// N'EST PAS ÉXÉCUTÉ
					HashTable.hgj(ligne, curseur, dessin, true);

					System.out.println("Ligne n° " + i + " :" + ligne);
					ligne = reader.readLine();
					i++;

				}

			} else
				System.out.println("Ce n'est pas un fichier txt");
		}

	}


	public boolean rightExtention(String way) {
		String sub = way.substring(way.length() - 3, way.length());
		return sub.equals("txt");
	}

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	class ExtensionFileFilter extends FileFilter {
		String description;

		String extensions[];

		public ExtensionFileFilter(String description, String extension) {
			this(description, new String[] { extension });
		}

		public ExtensionFileFilter(String description, String extensions[]) {
			if (description == null) {
				this.description = extensions[0];
			} else {
				this.description = description;
			}
			this.extensions = extensions.clone();
			toLower(this.extensions);
		}

		private void toLower(String array[]) {
			for (int i = 0, n = array.length; i < n; i++) {
				array[i] = array[i].toLowerCase();
			}
		}

		@Override
		public String getDescription() {
			return description;
		}

		@Override
		public boolean accept(File file) {
			if (file.isDirectory()) {
				return true;
			} else {
				String path = file.getAbsolutePath().toLowerCase();
				for (int i = 0, n = extensions.length; i < n; i++) {
					String extension = extensions[i];
					if ((path.endsWith(extension) && (path.charAt(path.length()
							- extension.length() - 1)) == '.')) {
						return true;
					}
				}
			}
			return false;
		}
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}
