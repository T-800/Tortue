package commande;

import ihm.Dessin;
import objetQuiDessine.CurseurQuiDessine;

public class Turn implements Commande {
/**
 * FINI
 */
	@Override
	public void execute(String[] parametres, Dessin dessin,	CurseurQuiDessine curseur, boolean addToHistory) {
		Integer x;
		char signe = parametres[1].charAt(0);
		if(signe == '+' ||signe == '-' ){
			String s = parametres[1].substring(1);
			x = Integer.parseInt(s);
			
			switch (signe) {
			case '+':

				x = (curseur.getDirection() + x.intValue()) % 360;
				curseur.setDirection(x.intValue());
				break;

			case '-':

				x = (curseur.getDirection() - x.intValue()) % 360;
				curseur.setDirection(x.intValue());
				break;

			}
		}else{
			x = Integer.parseInt(parametres[1]);
			x = x % 360;
			curseur.setDirection(x.intValue());
			if (addToHistory)
				history.addToHistory(ToString(parametres));

			
		}
	}


	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}


	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		
		if(parametres.length !=2)return 1;
		char signe = parametres[1].charAt(0);
		if(signe == '+' ||signe == '-' ){
			String s = parametres[1].substring(1);
			
			try {
				Integer.parseInt(s);

			} catch (NumberFormatException e1) {
				return 1;
			}
		}else{
			try {
				Integer.parseInt(parametres[1]);

			} catch (NumberFormatException e1) {
				return 1;
			}
		}
		return 0;
	}

}
