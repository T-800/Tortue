package commande;

import ihm.Dessin;
import ihm.PanelHistory;

import java.io.IOException;

import javax.swing.JPanel;

import objetQuiDessine.CurseurQuiDessine;

public class Remember implements Commande {

	// Sauvegarde la derniere position

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		// TODO Auto-generated method stub
		curseur.setRememberAbscisse(curseur.getAbscisse());
		curseur.setRememberOrdonnee(curseur.getOrdonnee());
		curseur.setRememberDirection(curseur.getDirection());
		if (addToHistory)
			history.addToHistory(ToString(parametres));
	}

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}
