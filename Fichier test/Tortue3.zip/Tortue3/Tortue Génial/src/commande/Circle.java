package commande;

import ihm.Dessin;
import java.awt.Color;
import java.awt.Stroke;

import commande.Move.Ligne;

import objetQuiDessine.CurseurQuiDessine;

public class Circle implements Commande {

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		// TODO Auto-generated method stub

		try {
			Integer x = Integer.parseInt(parametres[1]);
			Integer y = Integer.parseInt(parametres[2]);
			Cercle c = new Cercle(curseur.getAbscisse(),
					curseur.getOrdonnee()-x.intValue()/2, x.intValue(),
					curseur.getDirection(), y.intValue(), curseur.getCouleur(),
					null);
			double nX = curseur.getAbscisse() + x.intValue()
					* Math.cos(Math.toRadians(curseur.getDirection()));
			double nY = curseur.getOrdonnee() + x.intValue()
					* Math.sin(Math.toRadians(180 + curseur.getDirection()));
			curseur.setAbscisse((int) Math.round(nX));
			curseur.setOrdonnee((int) Math.round(nY));
			dessin.cmd.add(c);
			if (addToHistory)
				history.addToHistory(ToString(parametres));
		} catch (NumberFormatException e1) {
			System.err.println("AH AH ");
		}
		dessin.repaint();
	}

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	public class Cercle {
		private int xDepart;
		private int yDepart;
		private int degree;
		private int angle;
		private int rayon;
		private Color color;
		private Stroke strok;

		public Cercle(int xd, int yd, int rayon, int angle, int degree,
				Color color, Stroke strok) {
			this.xDepart = xd;
			this.yDepart = yd;
			this.rayon = rayon;
			this.degree = degree;
			this.color = color;
			this.strok = strok;
		}

		public int getAngle() {
			return this.angle;
		}

		public void setAngle(int angle) {
			this.angle = angle;
		}

		public int getDegree() {
			return this.degree;
		}

		public void setDegree(int degree) {
			this.degree = degree;
		}

		public int getRayon() {
			return this.rayon;
		}

		public void setRayon(int rayon) {
			this.rayon = rayon;
		}

		public Color getColor() {
			return color;
		}

		public void setColor(Color color) {
			this.color = color;
		}

		public Stroke getStrok() {
			return strok;
		}

		public void setStrok(Stroke strok) {
			this.strok = strok;
		}

		public int getxDepart() {
			return xDepart;
		}

		public void setxDepart(int xDepart) {
			this.xDepart = xDepart;
		}

		public int getyDepart() {
			return yDepart;
		}

		public void setyDepart(int yDepart) {
			this.yDepart = yDepart;
		}

	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}
