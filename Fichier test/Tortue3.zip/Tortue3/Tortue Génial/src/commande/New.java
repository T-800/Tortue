package commande;

import ihm.Dessin;

import java.io.IOException;

import javax.swing.JOptionPane;

import objetQuiDessine.CurseurQuiDessine;

public class New implements Commande {



	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		// TODO Auto-generated method stub
		JOptionPane boite = new JOptionPane();
		int option = JOptionPane.showConfirmDialog(null,
				"Voulez vous enregistrer votre dessin", "Tortue",
				JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);

		if (option == JOptionPane.YES_OPTION) {
			try {
				HashTable.hgj("SAVE", curseur, dessin, false);
				HashTable.hgj("CLEAR", curseur, dessin, false);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (option == JOptionPane.NO_OPTION) {
			try {
				HashTable.hgj("CLEAR", curseur, dessin, false);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (option == JOptionPane.CANCEL_OPTION) {

		}
	}

	

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

	// Faire un appel � save
	/*
	 * L'appel a SAVE doit ouvrir une fenetre pop up propose s'il veut
	 * sauvergarder ou non, s'il veut annuler sa commande alors la commande new
	 * est annul�
	 */

}
