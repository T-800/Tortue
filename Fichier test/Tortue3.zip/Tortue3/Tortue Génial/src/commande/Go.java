package commande;

import objetQuiDessine.CurseurQuiDessine;

import ihm.*;

public class Go implements Commande {


	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		// TODO Auto-generated method stub
		Integer x = Integer.parseInt(parametres[1]);
		Integer y = Integer.parseInt(parametres[2]);

		if (x > dessin.getWidth() / 2) {
			x = dessin.getWidth() / 2 - x;
		} else {
			x = dessin.getWidth() / 2 + x;
		}
		if (y < dessin.getHeight() / 2) {
			y = dessin.getHeight() / 2 - y;
			System.out.println(y);
		} else {
			y = dessin.getHeight() / 2 + y;
			
		}

		if (x.intValue() > dessin.getWidth() || x.intValue() < 0) {
			HashTable.panelHistory.addError("erreur x n'est pas dans le dessin");
			return;
		}
		if (y.intValue() > dessin.getHeight() || y.intValue() < 0) {
			// table.panel.addError("erreur y n'est pas dans le dessin");
			return;
		}

		if (addToHistory)
			history.addToHistory(ToString(parametres));
		curseur.setAbscisse(x.intValue());
		curseur.setOrdonnee(y.intValue());
		dessin.repaint();
	}


	@Override
	public String ToString(String[] tab) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}
}
