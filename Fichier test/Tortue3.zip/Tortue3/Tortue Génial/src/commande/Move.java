package commande;

import objetQuiDessine.CurseurQuiDessine;
import java.awt.Color;
import ihm.Dessin;
import java.awt.Stroke;

public class Move implements Commande {
	int LastMove = 0;

	String help = 
			"<p><b>MOVE : </b></p>";
	@Override
	public void execute(String[] parametres, Dessin dessin,CurseurQuiDessine curseur, boolean addToHistory) {
	
			
			Integer x;
			Integer y;
			
			
			// si move 10 10
			if (parametres.length == 3) {
				x = Integer.parseInt(parametres[1]);
				y = Integer.parseInt(parametres[2]);
			
				
				x=dessin.getWidth()/2+x;
				
				y =dessin.getHeight()/2-y;
				
				
			}
			//move 10
			else {
				Integer dist;
				try {
					dist = Integer.parseInt(parametres[1]);
				} catch (NumberFormatException e1) {
					dist = Integer.parseInt(parametres[1].substring(1));
				}
				switch (parametres[1].charAt(0)) {
					case '+':
						dist = LastMove + dist;
						break;
					case '-':
						dist = LastMove - dist;
						break;
					}

					LastMove = dist;

					x = (int) Math.round(curseur.getAbscisse()+ dist* Math.cos(Math.toRadians(curseur.getDirection())));
					y = (int) Math.round(curseur.getOrdonnee()+ dist* Math.sin(Math.toRadians(180 + curseur.getDirection())));
					
					//System.out.println("x : "+x.intValue()+" y : "+y.intValue());
			}
			
			
			

				Ligne l = new Ligne(curseur.getAbscisse(),curseur.getOrdonnee(), x.intValue(), y.intValue(),curseur.getCouleur(), null);
				curseur.setAbscisse(x.intValue());
				curseur.setOrdonnee(y.intValue());
			//	System.out.println("x : "+x.intValue()+" y : "+y.intValue());
				if (addToHistory)history.addToHistory(ToString(parametres));
				
				
				if (unique(l, dessin)) {
					dessin.cmd.add(l);
				}
				if (addToHistory)history.addToHistory(ToString(parametres));
				dessin.repaint();
	}
	
	
	

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,CurseurQuiDessine curseur) {
		Integer x;
		Integer y;
		if (!curseur.getPendown()) return 4;
		if (parametres.length == 3) {
			try {
				x = Integer.parseInt(parametres[1]);
				y = Integer.parseInt(parametres[2]);

			} catch (NumberFormatException e1) {
				return 1;
				//e1.
			}
			if (x > dessin.getWidth() / 2) {
				x = dessin.getWidth() / 2 - x;
			} else {
				x = dessin.getWidth() / 2 + x;
			}
			if (y < dessin.getHeight() / 2) {
				y = dessin.getHeight() / 2 - y;
			} else {
				y = dessin.getHeight() / 2 + y;
			}
			if (x.intValue() > dessin.getWidth() || x.intValue() < 0) {
				return 2;
			}
			if (y.intValue() > dessin.getHeight() || y.intValue() < 0) {
				return 2;
			}
			return 0;
		}else if (parametres.length == 2) {
			Integer dist;
			try {
				dist = Integer.parseInt(parametres[1]);
			} catch (NumberFormatException e1) {
				try{
					dist = Integer.parseInt(parametres[1].substring(1));
				}catch(NumberFormatException e){
					return 1;
				}
				
			}
			switch (parametres[1].charAt(0)) {
			case '+':
				dist = LastMove + dist;
				break;
			case '-':
				dist = LastMove - dist;
				break;
			}
			double nX = curseur.getAbscisse()+ dist* Math.cos(Math.toRadians(curseur.getDirection()));
			double nY = curseur.getOrdonnee()+ dist* Math.sin(Math.toRadians(180 + curseur.getDirection()));
			if (nX > dessin.getWidth() || nX < 0) {
				return 2;
			}
			if (nY > dessin.getHeight() || nY < 0) {		
				return 2;
			}
			return 0;	
			
		}else {
			return 3;
		}
		
	}

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	private boolean unique(Ligne l, Dessin dessin) {

		for (Object p : dessin.cmd) {
			if (p.getClass().equals(Ligne.class)) {
				if (dessin.egaux(l, (Ligne) p))
					return false;
			}

		}

		return true;
	}

	public class Ligne {
		private int xDepart;
		private int yDepart;
		private int xArrivee;
		private int yArrivee;
		private Stroke strok;
		private Color color;

		public Ligne(int xd, int yd, int xa, int ya, Color color, Stroke strok) {
			this.xDepart = xd;
			this.yDepart = yd;
			this.xArrivee = xa;
			this.yArrivee = ya;
			this.color = color;
			this.strok = strok;
		}

		public Color getColor() {
			return color;
		}

		public void setColor(Color color) {
			this.color = color;
		}

		public Stroke getStrok() {
			return strok;
		}

		public void setStrok(Stroke strok) {
			this.strok = strok;
		}

		public int getxDepart() {
			return xDepart;
		}

		public void setxDepart(int xDepart) {
			this.xDepart = xDepart;
		}

		public int getyDepart() {
			return yDepart;
		}

		public void setyDepart(int yDepart) {
			this.yDepart = yDepart;
		}

		public int getxArrivee() {
			return xArrivee;
		}

		public void setxArrivee(int xArrivee) {
			this.xArrivee = xArrivee;
		}

		public int getyArrivee() {
			return yArrivee;
		}

		public void setyArrivee(int yArrivee) {
			this.yArrivee = yArrivee;
		}

	}


}
