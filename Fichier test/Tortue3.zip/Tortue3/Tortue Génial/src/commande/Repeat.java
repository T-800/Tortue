package commande;

import ihm.Dessin;

import java.io.IOException;

import objetQuiDessine.CurseurQuiDessine;

public class Repeat implements Commande {

	/**
	 * La syntaxe de repeat est REPEAT nbFois [cmd1;cmd2;cmd3]
	 */

	public Repeat() {

	}

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		String d = ToString(parametres);
		System.out.println(d + "  d");
		Object[] tab = convertTo(parametres);
		
		
		for (int i = 0; i < (Integer) tab[0]; i++) {
			for (int j = 1; j < tab.length; j++) {
				try {
					HashTable.hgj((String) tab[j], curseur, dessin, false);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		history.addToHistory(d);

	}

	public Object[] convertTo(String[] parametres) {
		parametres[2] = parametres[2].replaceAll("\\[", "");
		parametres[2] = parametres[2].replaceAll("\\]", "");
		String[] cmd = parametres[2].split(";");
		for (int i = 1; i < cmd.length; i++) {
			cmd[i] = HashTable.syntaxe(cmd[i]);
		}
		Object[] tab = new Object[cmd.length + 1];
		tab[0] = Integer.parseInt(parametres[1]);

		for (int i = 1; i < tab.length; i++) {
			tab[i] = cmd[i - 1];
		}
		return tab;
	}

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			if(i==2)s+="[";
			s += tab[i] + " ";
		}
		return s+"]";
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		
		Object[] tab = convertTo(parametres);
		for (int i = 1; i < tab.length; i++) {
			String s = (String) tab[i];
			String t[] = s.split(" ");
			System.out.println(t[0]);
			t[0] = t[0].toUpperCase();
			if (!HashTable.hashCommande.containsKey(t[0].toUpperCase().trim())) {
				return 5;
			}
			//System.out.println("essai"+t[0] + " "+t[1]);
			if(!HashTable.itsOK(t, true, dessin, curseur)){
				return 6;
			}
		}
		return 0;
	}

}
