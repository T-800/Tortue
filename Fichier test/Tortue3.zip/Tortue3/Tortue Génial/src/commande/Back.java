package commande;

import ihm.Dessin;

import java.io.IOException;

import objetQuiDessine.CurseurQuiDessine;

/**
 * Classe de la comande Back on done au curseur les valeurs que 
 * l'on sauvegarder avec Remember
 * 
 *
 */
public class Back implements Commande {

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) throws IOException {
		/*
		 * On donne au curseur les valeurs que l'on a s
		 */
		curseur.setAbscisse(curseur.getRememberAbscisse());
		curseur.setOrdonnee(curseur.getRememberOrdonnee());
		curseur.setDirection(curseur.getRememberDirection());
		dessin.repaint();
		if (addToHistory)
			history.addToHistory(ToString(parametres));
	}

	

	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}
