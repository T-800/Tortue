package commande;

import java.util.ArrayList;

import ihm.Dessin;
import ihm.Fenetre;
import objetQuiDessine.CurseurQuiDessine;

public class Clear implements Commande {

	public Clear() {
	}

	@Override
	public void execute(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur, boolean addToHistory) {
		history.reset();
		dessin.cmd = new ArrayList<Object>();
		
		dessin.repaint();

	}


	@Override
	public String ToString(String[] tab) {
		String s = "";

		for (int i = 0; i < tab.length; i++) {
			s += tab[i] + " ";
		}
		return s;
	}

	@Override
	public int canDoIt(String[] parametres, Dessin dessin,
			CurseurQuiDessine curseur) {
		// TODO Auto-generated method stub
		return 0;
	}

}