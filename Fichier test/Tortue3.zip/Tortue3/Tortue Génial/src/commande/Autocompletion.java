package commande;

import java.util.ArrayList;
/**
 * Corriger les erreurs le crochet disparait et ajouter les lettre possible en plus 
 * @author slater
 *
 */
public class Autocompletion {

	final static String[] commande = { "BACK", "BACKGROUNDCOLOR", "CENTER", "CIRCLE",
			"CLEAR", "DOWN", "ERASE", "HELP", "LEFT", "MOVE", "NEW", "OPEN",
			"PENCOLOR", "PENDOWN", "PENSIZE", "PENUP", "REDO", "REMEMBER",
			"REPEAT", "RIGHT", "SAVE", "TURN", "UNDO", "UP" };

	public Autocompletion() {

	}

	public static ArrayList<String> search(String word){
		ArrayList<String> word_find = new ArrayList<String>();

		for(String s : commande){
			if(!(s.length() < word.length())){
				String sub = s.substring(0,word.length());
				if(word.equals(sub)) word_find.add(s);
			}
		}
		return word_find;
	}

	public static String extraChar(String word, ArrayList<String> word_find_list){
		//TODO : A faire
		return word;
	}

	public static ArrayList<String> complete(String terminal){
		terminal=terminal.toUpperCase();
		
		String [] decoup_terminal = terminal.split(" ");



		String word_to_search = decoup_terminal[decoup_terminal.length-1];
		char non_char = word_to_search.charAt(0);
		word_to_search = word_to_search.replaceAll("\\W", " ");
		

		ArrayList<String> word_find = search(word_to_search);
		if(word_find.size() ==1){
			String tmp = "";
			for (int i=0;i<decoup_terminal.length-1 ;i++ ) {
				tmp += " "+decoup_terminal[i];
			}
			tmp += " "+word_find.get(0);
			word_find.set(0, tmp);
			return word_find;
		}
		System.out.println(word_find.size());

		word_to_search  = extraChar(word_to_search,word_find);
		

		//if(decoup_terminal.length>1){
			String tmp = "";
			for (int i=0;i<decoup_terminal.length-1 ;i++ ) {
				tmp += " "+decoup_terminal[i];
			}
			tmp += " "+word_to_search;
			word_to_search = tmp;

		//}
		word_find.add(word_to_search);
		System.out.println(word_find.get(word_find.size()-1));
		return word_find;
	}









































	/*

	public ArrayList<String> search(String clavier, JTextField jInviteDeCommande) {
		clavier.trim();
		clavier = clavier.toUpperCase();
		String [] s = clavier.split(" ");
		clavier = s[s.lenght-1];
		ArrayList<String> tab = new ArrayList<String>();
		for (int i = 0; i < this.commande.length; i++) {
			if (compare(clavier, commande[i])) {
				tab.add(commande[i]);
			}

		}
		String tmp = word(tab);
		if (tmp.length() > clavier.length()) {
			jInviteDeCommande.setText(tmp);
			
		}
		return tab;

	}

	public boolean compare(String un, String deux) {
		if (deux.length() < un.length())
			return false;
		for (int i = 0; i < un.length(); i++) {
			if (!(un.charAt(i) == deux.charAt(i)))
				return false;
		}
		return true;
	}

	public String word(ArrayList<String> list) {
		String word = "";
		char tmp;
		int index = 0;
		for (int i = 1; i < list.size(); i++) {
			if (list.get(i).length() < list.get(index).length()) {
				index = i;
			}
		}
		String test = list.get(index);
		
		for (int i = 0; i < test.length(); i++) {
			tmp = test.charAt(i);

			for (int j = 0; j < list.size(); j++) {
				if (tmp != list.get(j).charAt(i)) {
					return word;
				}
			}
			word += tmp;
			
		}

		return word;
	}*/

}
