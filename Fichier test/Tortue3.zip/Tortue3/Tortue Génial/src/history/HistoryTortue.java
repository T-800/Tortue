package history;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class HistoryTortue implements History{
	
	private static ArrayList<String> history;
	
	private ArrayList<String> undo;
	
	
	public HistoryTortue(){
		history = new ArrayList<String>();
		undo = new ArrayList<String>();
	
	}

	@Override
	public void addToHistory(String Comande){
		history.add(Comande);
		//show();
	}

	public void removeAll(){
		for(int i= HistoryTortue.history.size()-1;i>=0;i--){
			HistoryTortue.history.remove(i);
		}
	}

	@Override
	public void removeToHistory() throws IOException {
		if(!HistoryTortue.history.isEmpty()){
			for(int i= HistoryTortue.history.size()-1;i>=0;i--){
				String s = history.get(i).substring(0,history.get(i).indexOf(" "));
				
				if(s.equals("MOVE")){
					String suppr = HistoryTortue.history.get(i);
					this.undo.add(suppr);
					HistoryTortue.history.remove(i);
					//System.out.println("m : "+this.undo.get(0));
					return;
					
				}
				else if(s.equals("CIRCLE")){
					String suppr = HistoryTortue.history.get(history.size()-1);
					this.undo.add(suppr);
					HistoryTortue.history.remove(history.size()-1);
					System.out.println("c : "+this.undo.get(0));
					return;
					
				}
				if(s.equals("REPEAT")){
					String suppr = HistoryTortue.history.get(history.size()-1);
					this.undo.add(suppr);
					HistoryTortue.history.remove(history.size()-1);
					System.out.println("r : "+this.undo.get(0));
					return;
					
				}
				
			}
			
			
		}
		this.show();
	}
	
	public void show(){
		for(int i = 0; i < HistoryTortue.history.size(); i++){
	      System.out.println("History " + i + " = " + HistoryTortue.history.get(i));
	    }
		for(int i = 0; i < undo.size(); i++){
		      System.out.println("UNDO " + i + " = " + undo.get(i));
		    }   
	}

	@Override
	public void saveHistory(String chemin) throws IOException {
		/*
		 * Si le chmin a déjà une extension on la retire et on la stock
		 * Et on la rajoute a la fin ; 
		 */
		File destination = new File(chemin+".txt");
		
		BufferedWriter output; 
		output = new BufferedWriter(new FileWriter(destination));
		
		int ligne=0;
		while(ligne<history.size()){
			try { 

		
			output.write(history.get(ligne)+"\r\n"); 
			output.flush(); 
		
		

			} 
			catch(IOException ioe){ 
				System.out.println("erreur : " + ioe ); 
			} 
			//history.renameTo(destination);
			ligne++;
		}
		output.close();
	}
	
	public void redo(){
		if(undo.isEmpty()){
			
		}
		else {
			String redo = this.undo.get(undo.size()-1);
			this.addToHistory(redo);
			this.undo.remove(undo.size()-1);

		}
				
		//show();
	}
	
	public void reset(){
		HistoryTortue.history = new ArrayList<String>();
		this.undo= new ArrayList<String>();
	}


	
	
	/****
	 * GET et SET
	 */
	
	
	
	public ArrayList<String> getHistory() {
		return history;
	}

	public void setHistory(ArrayList<String> history) {
		HistoryTortue.history = history;
	}

	public ArrayList<String> getUndo() {
		return undo;
	}

	public void setUndo(ArrayList<String> undo) {
		this.undo = undo;
	}


}