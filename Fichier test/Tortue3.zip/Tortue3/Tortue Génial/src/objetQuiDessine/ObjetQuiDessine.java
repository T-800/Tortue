package objetQuiDessine;

public interface ObjetQuiDessine {
	
}
