package objetQuiDessine;
import ihm.Info;

import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class CurseurQuiDessine implements ObjetQuiDessine{
	
	private int direction, abscisse, ordonnee;
	private Color couleur;
	private boolean pendown;
	private int pensize; 
	private int rememberAbscisse, rememberOrdonnee, rememberDirection;
	private Color background;
	

	private Info info;
	private Image curseurImg;
	
	public CurseurQuiDessine(Info info, int x,int y){
		this.info = info;
		this.abscisse =x ;
		this.ordonnee =y ; 
		this.pensize=1;
		this.couleur=Color.BLACK;
		this.direction =0;
		this.pendown=true;
		try {
			curseurImg  = ImageIO.read(new File("../Image/arrow.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("pas d'image");
			e.printStackTrace();
		}
		
	}

	

	/*
	 * GET et SET
	 */



	public int getDirection() {
		return direction;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public int getAbscisse() {
		return abscisse;
	}

	public void setAbscisse(int abscisse) {
		this.abscisse = abscisse;
	}

	public int getOrdonnee() {
		return ordonnee;
	}

	public void setOrdonnee(int ordonnee) {
		this.ordonnee = ordonnee;
	}

	public Color getCouleur() {
		return couleur;
	}

	public void setCouleur(Color couleur) {
		this.couleur = couleur;
	}

	public boolean getPendown() {
		return pendown;
	}

	public void setPendown(boolean pendown) {
		this.pendown = pendown;
	}

	public int getPensize() {
		return pensize;
	}

	public void setPensize(int pensize) {
		this.pensize = pensize;
	}

	
	public int getRememberAbscisse() {
		return rememberAbscisse;
	}

	public void setRememberAbscisse(int rememberAbscisse) {
		this.rememberAbscisse = rememberAbscisse;
	}

	public int getRememberOrdonnee() {
		return rememberOrdonnee;
	}

	public void setRememberOrdonnee(int rememberOrdonnee) {
		this.rememberOrdonnee = rememberOrdonnee;
	}

	public int getRememberDirection() {
		return rememberDirection;
	}

	public void setRememberDirection(int rememberDirection) {
		this.rememberDirection = rememberDirection;
	}

	public Color getBackground() {
		return background;
	}

	public void setBackground(Color background) {
		this.background = background;
	}

	public Info getInfo() {
		return info;
	}

	public void setInfo(Info info) {
		this.info = info;
	}
	
	public Image getCurseurImg() {
		return curseurImg;
	}



	public void setCurseurImg(Image curseurImg) {
		this.curseurImg = curseurImg;
	}
	
}