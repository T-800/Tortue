package objetQuiDessine;

import ihm.Dessin;
import ihm.Info;

public class GommeQuiEfface extends CurseurQuiDessine implements ObjetQuiDessine {

	public GommeQuiEfface(Info info, int x,int y) {
	super(info, x,y);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
