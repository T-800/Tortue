package objetQuiDessine;

import ihm.Dessin;
import ihm.Info;

public class SymboleQuiDessine extends CurseurQuiDessine{

	public SymboleQuiDessine(Info info, int x,int y) {
		super(info, x,y);
		// TODO Auto-generated constructor stub
	}

}
